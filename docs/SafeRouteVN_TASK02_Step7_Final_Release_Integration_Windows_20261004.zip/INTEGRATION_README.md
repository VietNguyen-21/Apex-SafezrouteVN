# M3/M4 candidate

Runtime and Integration production files are identical. Frozen API v1 is complete (34 files). Dynamic plans use SDK/job-view/execution-view, not a fabricated API v1 route. Run all exact portable commands in docs/step7_INTEGRATION_CROSSWALK.md; then run `node optimization/tests/runtime_m4_flow.mjs examples/S2_execution_view.json` (repeat S3/S4). Source-backed tests require FULL TASK02, reviewed historical runs and external M1. This package does not implement backend/frontend. Leader reviews delivery receipt before handoff.
